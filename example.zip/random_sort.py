import random
l = [1, 2, 3 ]
attemtps = 0

sorted_l = sorted(l)

while l != sorted_l:
    attemt +=1
    random.shuffle(l)
